package com.powerbridge.example.service;

import java.util.List;

import com.baomidou.mybatisplus.service.IService;
import com.powerbridge.example.entity.Echo;

/**
 * @Description: 
 * @author: shunhe@powerbridge.com
 * @Date: 2018年1月19日下午3:04:24
 */
public interface IEchoService extends IService<Echo> {

	public Echo findByUUID(String uuid);
	
	public Echo findSlaveByUUID(String uuid);
	
	public boolean batchInsertEcho(List<Echo> list);
}

