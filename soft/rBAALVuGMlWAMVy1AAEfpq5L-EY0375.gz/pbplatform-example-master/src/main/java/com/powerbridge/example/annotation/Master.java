package com.powerbridge.example.annotation;

import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;


/**
 * @Description: 
 * @author: shunhe@powerbridge.com
 * @Date: 2018年4月17日下午5:56:02
 */
@Retention(RUNTIME)
@Target({ TYPE, METHOD })
public @interface Master {

}

