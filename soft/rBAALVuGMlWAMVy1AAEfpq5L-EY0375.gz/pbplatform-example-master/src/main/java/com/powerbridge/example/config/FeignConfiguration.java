package com.powerbridge.example.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.powerbridge.example.service.FeignErrorDecoder;

/**
 * @Description: 
 * @author: shunhe@powerbridge.com
 * @Date: 2018年1月11日下午2:40:38
 */
@Configuration
public class FeignConfiguration {

	@Bean
    public FeignErrorDecoder errorDecoder(){
        return new FeignErrorDecoder();
    }
}

