package com.powerbridge.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.web.servlet.MultipartAutoConfiguration;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.EnableMBeanExport;
import org.springframework.context.annotation.Import;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jmx.support.RegistrationPolicy;

import com.github.tobato.fastdfs.FdfsClientConfig;
import com.powerbridge.core.config.GlobalSecurityConfigAdapter;
import com.powerbridge.core.config.MultipartResolverConfig;
import com.powerbridge.core.config.RedisConfig;
import com.powerbridge.core.repository.base.BaseRepositoryFactoryBean;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * 启动
 * shunhe@powerbridge.com
 * 2017年11月3日上午10:56:30
*/
@SpringBootApplication
@EnableSwagger2
@EnableFeignClients
@EnableJpaRepositories(repositoryFactoryBeanClass = BaseRepositoryFactoryBean.class)
@Import({FdfsClientConfig.class, MultipartResolverConfig.class, GlobalSecurityConfigAdapter.class, RedisConfig.class})
@EnableMBeanExport(registration = RegistrationPolicy.IGNORE_EXISTING)
@EnableAutoConfiguration(exclude = {MultipartAutoConfiguration.class})
@EnableDiscoveryClient
public class ExampleApplication /*支持外置tomcat部署服务 extends SpringBootServletInitializer*/{

    public static void main(String[] args) {
        SpringApplication.run(ExampleApplication.class, args);
    }
    
//	支持外置tomcat部署服务    
//    @Override
//	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
//		return application.sources(ExampleApplication.class);
//	}

}
