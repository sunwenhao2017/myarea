package com.powerbridge.example.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.Locale;

/**
 * @Description: 系统语言环境设置
 * @author: shindoyang@powerbridge.com
 * @Date: 2018年8月27日上午10:19:09
 */
@Component
public class LangSwitchConfig {

    @Autowired
    private ExampleConfig exampleConfig;

    @PostConstruct
    public void setEnvLang(){
        Locale.setDefault(new Locale(exampleConfig.getLanguage()));
    }
}
