package com.powerbridge.example.client.impl;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.powerbridge.core.constants.MessageConstants;
import com.powerbridge.core.dto.AjaxResult;
import com.powerbridge.core.util.json.JSONObject;
import com.powerbridge.example.client.IExampleSystemClient;
import com.powerbridge.example.entity.Echo;
/**
 * @Description: 
 * @author: shunhe@powerbridge.com
 * @Date: 2018年5月29日上午10:24:07
 */
@Component
public class IExampleSystemClientImpl implements IExampleSystemClient {

	@Override
	public AjaxResult getString(String str) {
		// TODO Auto-generated method stub
		return new AjaxResult(MessageConstants.FALLBACK_ERROR);
	}

	@Override
	public AjaxResult getMap(Map<String, Object> map) {
		// TODO Auto-generated method stub
		return new AjaxResult(MessageConstants.FALLBACK_ERROR);
	}

	@Override
	public AjaxResult getJson(JSONObject json) {
		// TODO Auto-generated method stub
		return new AjaxResult(MessageConstants.FALLBACK_ERROR);
	}

	@Override
	public AjaxResult getLoginUser() {
		// TODO Auto-generated method stub
		return new AjaxResult(MessageConstants.FALLBACK_ERROR);
	}

}
