package com.powerbridge.example.config;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.sql.DataSource;

import org.apache.ibatis.mapping.DatabaseIdProvider;
import org.apache.ibatis.mapping.VendorDatabaseIdProvider;
import org.apache.ibatis.plugin.Interceptor;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;
import org.springframework.util.StringUtils;

import com.alibaba.druid.pool.DruidDataSource;
import com.baomidou.mybatisplus.MybatisConfiguration;
import com.baomidou.mybatisplus.entity.GlobalConfiguration;
import com.baomidou.mybatisplus.spring.MybatisSqlSessionFactoryBean;
import com.baomidou.mybatisplus.spring.boot.starter.SpringBootVFS;
import com.powerbridge.core.advice.WhenDidInterceptor;
import com.powerbridge.core.mybatisPlus.PaginationInterceptor;

/**
 * @Description: 
 * @author: shunhe@powerbridge.com
 * @Date: 2018年1月23日上午9:45:22
 */
@Configuration
@MapperScan(basePackages= {"com.powerbridge.example.dao"}, sqlSessionFactoryRef = "sqlSessionFactory")
public class DataSourceConfig {

	@Autowired
	private ExampleConfig config;
	
	@Autowired
    private ApplicationContext appContext;
	
	@Bean
    public PaginationInterceptor mySqlPaginationInterceptor() {
        PaginationInterceptor page = new PaginationInterceptor();
        page.setDialectType(config.getMasterPaginationInterceptor());
        return page;
    }
	
	@Bean
	public WhenDidInterceptor whenDidInterceptor() {
		return new WhenDidInterceptor();
	}
	
	@Bean
	public GlobalConfiguration globalConfiguration() {
		GlobalConfiguration golbalConfiguration = new GlobalConfiguration();
		return golbalConfiguration;
	}
	
	@Bean(name = "slave")
	@Qualifier("slave")
    public DataSource masterDataSource() {
        DruidDataSource dataSource = new DruidDataSource();
        dataSource.setDriverClassName(config.getSlaveDriver());
        dataSource.setUrl(config.getSlaveUrl());
        dataSource.setUsername(config.getSlaveUsername());
        dataSource.setPassword(config.getSlavePassword());
        return dataSource;
    }
	
	@Bean(name = "master")
	@Qualifier("master")
	@Primary
    public DataSource slaveDataSource() {
        DruidDataSource dataSource = new DruidDataSource();
        dataSource.setDriverClassName(config.getMasterDriver());
        dataSource.setUrl(config.getMasterUrl());
        dataSource.setUsername(config.getMasterUsername());
        dataSource.setPassword(config.getMasterPassword());
        return dataSource;
    }

    @Bean
    public AbstractRoutingDataSource roundRobinDataSouceProxy(@Qualifier("master")DataSource master,  @Qualifier("slave") DataSource slave) {
        RWSplitRoutingDataSource proxy = new RWSplitRoutingDataSource();
        Map<Object, Object> targetDataSources = new HashMap<Object, Object>();
        targetDataSources.put(DbContextHolder.DbType.MASTER, master);
        targetDataSources.put(DbContextHolder.DbType.SLAVE,  slave);
        proxy.setDefaultTargetDataSource(master);
        proxy.setTargetDataSources(targetDataSources);
        return proxy;
    }

    @Bean(name="sqlSessionFactory")
    public SqlSessionFactory sqlSessionFactory(@Qualifier("master")DataSource master, @Qualifier("slave") DataSource slave) throws Exception {
    	final MybatisSqlSessionFactoryBean  sessionFactory = new MybatisSqlSessionFactoryBean();       
        sessionFactory.setDataSource((DataSource)appContext.getBean("roundRobinDataSouceProxy"));
        sessionFactory.setVfs(SpringBootVFS.class);
        MybatisConfiguration mc = new MybatisConfiguration();
        sessionFactory.setConfiguration(mc);
        if (StringUtils.hasLength(config.getMyBatisTypeAliasesPackage())) {
        	sessionFactory.setTypeAliasesPackage(config.getMyBatisTypeAliasesPackage());
	    }
	    if(StringUtils.hasLength(config.getMasterXmlLocation())) {
	    	sessionFactory.setMapperLocations(new PathMatchingResourcePatternResolver()
	                  .getResources(config.getMasterXmlLocation()));
	    }
	    Interceptor[] interceptor = {mySqlPaginationInterceptor(),whenDidInterceptor()};
	    sessionFactory.setPlugins(interceptor);
	    sessionFactory.setDatabaseIdProvider(getDatabaseIdProvider());
	    sessionFactory.setGlobalConfig(globalConfiguration());
        return sessionFactory.getObject();
    }
    
    @Bean
    public DatabaseIdProvider getDatabaseIdProvider() {
	    DatabaseIdProvider databaseIdProvider = new VendorDatabaseIdProvider();
	    Properties p = new Properties();
	    p.setProperty("Oracle", "oracle");
	    p.setProperty("MySQL", "mysql");
	    p.setProperty("SqlServer", "sqlserver");
	    databaseIdProvider.setProperties(p);
	    return databaseIdProvider;
    }
}

