package com.powerbridge.example.client.impl;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.powerbridge.core.constants.MessageConstants;
import com.powerbridge.core.dto.AjaxResult;
import com.powerbridge.example.client.IExampleCodClient;
/**
 * @Description: 
 * @author: shunhe@powerbridge.com
 * @Date: 2018年5月29日上午10:24:07
 */
@Component
public class IExampleCodClientImpl implements IExampleCodClient {

	@Override
	public String getCusValue(String tableNames, String value) {
		// TODO Auto-generated method stub
		return MessageConstants.FALLBACK_ERROR.getMessage();
	}

	@Override
	public AjaxResult showCodCusClassifyList(Map<String, Object> map) {
		// TODO Auto-generated method stub
		return new AjaxResult(MessageConstants.FALLBACK_ERROR);
	}

}
