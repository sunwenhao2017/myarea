package com.powerbridge.example.service;


import com.powerbridge.example.config.ExampleConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Service;

import java.util.Locale;

@Service
public class MessageService {
    @Autowired
    protected MessageSource messageSource;

    @Autowired
    private ExampleConfig exampleConfig;

    /**
     * 获取错误码描述信息
     *
     * @param code 错误码
     * @return 国际化信息
     */
    public String getMsg(String code) {
        //可在springboot项目的启动类main方法,设置项目部署语言环境Locale.setDefault(Locale.CHINESE);
        /**
         * 在启动类设置过locale为zh.所以下面MessageSource会加载messages_zh.properties文件;
         * 项目需要用到哪些语言环境,就需要创建对应的messages_xx.properties文件.
         * 例如,语言环境现在是en_US,那么就需要创建messages_en_US.proiperties文件
         */
        Locale locale = LocaleContextHolder.getLocale();
        try {
            return messageSource.getMessage(code, null, locale);
        } catch (NoSuchMessageException e) {
            return "ResultCode:" + code;
        }
    }
}