package com.powerbridge.example.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.ctrip.framework.apollo.spring.annotation.EnableApolloConfig;

/**
 * @Description: 
 * @author: shunhe@powerbridge.com
 * @Date: 2017年11月20日上午10:19:09
 */
@Configuration
@EnableApolloConfig({"application","DEPT.testpublic"})
public class ApolloExampleConfig {
	@Bean
	public ExampleApolloAnnotationBean batchApolloAnnotationBean() {
		return new ExampleApolloAnnotationBean();
	}
}

