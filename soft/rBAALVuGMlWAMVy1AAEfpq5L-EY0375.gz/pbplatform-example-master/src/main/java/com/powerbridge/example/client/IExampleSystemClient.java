package com.powerbridge.example.client;

import java.util.Map;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.powerbridge.core.dto.AjaxResult;
import com.powerbridge.core.util.json.JSONObject;
import com.powerbridge.example.client.impl.IExampleSystemClientImpl;
import com.powerbridge.example.entity.Echo;

/**
 * @Description: 
 * @author: shunhe@powerbridge.com
 * @Date: 2018年5月29日上午10:24:12
 */
@FeignClient(name = "pbplatform-system", fallback = IExampleSystemClientImpl.class)
public interface IExampleSystemClient {

	@RequestMapping(method = RequestMethod.POST, value = "/system/getString")
	AjaxResult getString(@RequestBody String str);
	
	@RequestMapping(method = RequestMethod.POST, value = "/system/getMap")
	AjaxResult getMap(@RequestParam Map<String, Object> map);
	
	@RequestMapping(method = RequestMethod.POST, value = "/system/getJsonObject")
	AjaxResult getJson(@RequestBody JSONObject json);
	
	@RequestMapping(method = RequestMethod.GET, value = "/system/sysuser/loginuser")
	AjaxResult getLoginUser();
}

