package com.powerbridge.example.repository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.powerbridge.core.repository.base.BaseRepository;
import com.powerbridge.example.entity.Echo;

/**
 * @Description: 
 * @author: shunhe@powerbridge.com
 * @Date: 2018年6月19日下午5:55:11
 */
public interface EchoRepository extends BaseRepository<Echo, String>{

	@Query("from Echo e where e.msg=:msg")
	public Echo findByMsg(@Param("msg") String msg);
	
	@Query(value = "update Echo set msg=?1 where id=?2",nativeQuery = true)
    @Modifying
    @Transactional
    public int updateById(String msg,String id);
}

