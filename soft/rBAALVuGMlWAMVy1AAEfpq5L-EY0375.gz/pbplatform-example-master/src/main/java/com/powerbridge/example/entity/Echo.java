package com.powerbridge.example.entity;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Description: example entity
 * @author: shunhe@powerbridge.com
 * @Date: 2017年11月13日下午5:20:23
 */
@Data
@Entity
@Table(name = "echo")
public class Echo implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@TableId
	@Column(name = "id", unique = true, nullable = false)
	@ApiModelProperty(value="主键ID", name="id", example="")
	private String id;
	
	@Column(name = "msg")
	@ApiModelProperty(value="消息内容", name="msg", allowEmptyValue=true, example="")
	private String msg;
	
	@TableField(value="name")
	@ApiModelProperty(value="消息名称", name="name", allowEmptyValue=true, example="")
	private String name;
	
}

