package com.powerbridge.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.powerbridge.core.constants.MessageConstants;
import com.powerbridge.core.controller.BaseController;
import com.powerbridge.core.dto.AjaxResult;
import com.powerbridge.core.util.EncryptUtil;
import com.powerbridge.example.config.ExampleConfig;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

/**
 * @Description: 加密操作接口
 * @author: shunhe@powerbridge.com
 * @Date: 2018年6月28日上午10:42:42
 */
@RestController
@RequestMapping("/jasypt")
@Api(description="Jasypt Example Controller", tags= {"加密操作接口"})
public class JasyptEncryptionController extends BaseController {

	@Autowired
	private ExampleConfig config;
	
	@ApiOperation(value="加密", notes="相关提示内容可在此处填写")
	@PostMapping("/encryptParam")
	@ApiImplicitParam(name="encryptParam", value="明文参数", required=true, paramType="body")
    public AjaxResult updateEchoById(@RequestBody @ApiIgnore String param) {
		String result = EncryptUtil.getEncrypted(param, config.getEncryptorPassword());
		return json(MessageConstants.BSSP_STATUS_SUCCESS, result);
	}
	
	@ApiOperation(value="解密", notes="相关提示内容可在此处填写")
	@PostMapping("/decryptParam")
    public AjaxResult decryptParam() {
		return json(MessageConstants.BSSP_STATUS_SUCCESS, config.getEncrpytionParams());
	}
}

