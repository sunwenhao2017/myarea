package com.powerbridge.example.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.powerbridge.core.service.impl.BaseServiceImpl;
import com.powerbridge.example.annotation.Slave;
import com.powerbridge.example.dao.EchoMapper;
import com.powerbridge.example.entity.Echo;
import com.powerbridge.example.service.IEchoService;

@Service
public class EchoServiceImpl extends BaseServiceImpl<EchoMapper,Echo> implements IEchoService{
	
	@Autowired
	private EchoMapper master;
	
	@Override
	public Echo findByUUID(String uuid) {
		return master.getEchoById(uuid);
	}
	
	@Slave
	@Override
	public Echo findSlaveByUUID(String uuid) {
		return master.getEchoById(uuid);
	}

	@Override
	public boolean batchInsertEcho(List<Echo> list) {
		return insertBatch(list);
	}
}

