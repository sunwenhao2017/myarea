package com.powerbridge.example.controller;

import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.powerbridge.core.controller.BaseController;
import com.powerbridge.core.itf.EurekaManageInterface;
import com.powerbridge.core.util.PostUtils;
import com.powerbridge.example.config.ExampleConfig;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * @Description: 服务启停接口
 * @author: shunhe@powerbridge.com
 * @Date: 2018年5月8日下午5:42:07
 */
@Controller
@RequestMapping("/eureka/")
@Api(description="Eureka Client Controller")
public class ClientController extends BaseController{

	private static final Logger LOGGER = LoggerFactory.getLogger(ClientController.class);

	@Autowired
	private ExampleConfig exampleConfig;
	
	@ResponseBody
	@RequestMapping(value = "apps", method = RequestMethod.GET)
	public String apps() {
		return PostUtils.sendHttpGet(exampleConfig.getEurekaClientinfoUrl());
	}

	@ResponseBody
	@RequestMapping(value = "operate", method = RequestMethod.POST)
	@ApiOperation("服务启停")
	public String operate(@RequestBody HashMap<String, String> inmap) {
		LOGGER.info(inmap.toString());
		if (inmap.get("operate").equals("1")) {// 暂停
			EurekaManageInterface.upOrDown=false;
		}else if (inmap.get("operate").equals("3")) {// 恢复
			EurekaManageInterface.upOrDown=true;
		}
		return "success";
	}
}

