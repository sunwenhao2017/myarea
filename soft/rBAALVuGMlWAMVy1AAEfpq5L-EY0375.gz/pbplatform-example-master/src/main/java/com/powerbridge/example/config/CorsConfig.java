package com.powerbridge.example.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * @Description: 全局跨域处理
 * @author: shunhe@powerbridge.com
 * @Date: 2018年1月16日下午6:58:28
 */
@Configuration
public class CorsConfig{
	
	@Bean
	public WebMvcConfigurer corsConfigurer() {
		return new WebMvcConfigurer() {
			@Override
			public void addCorsMappings(CorsRegistry registry) {
				registry.addMapping("/v2/**").allowedOrigins("http://172.16.0.42:8899");
				registry.addMapping("/eureka/**");
				registry.addMapping("/echo/**").allowedOrigins("http://172.16.0.42:8899");
			}
		};
	}

}

