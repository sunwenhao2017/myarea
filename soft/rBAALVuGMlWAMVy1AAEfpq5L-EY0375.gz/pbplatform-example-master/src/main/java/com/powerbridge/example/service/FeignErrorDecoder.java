package com.powerbridge.example.service;

import com.netflix.hystrix.exception.HystrixBadRequestException;

import feign.FeignException;
import feign.Response;
import feign.codec.ErrorDecoder;

/**
 * @Description: 服务调用异常处理
 * @author: shunhe@powerbridge.com
 * @Date: 2018年1月11日下午2:25:11
 */
public class FeignErrorDecoder implements ErrorDecoder {
	
	@Override
	public Exception decode(String methodKey, Response response) {
        Exception exception = null;
        if((response.status() >= 400 && response.status() <= 499) || response.status()==999){
            return new HystrixBadRequestException("系统服务出现异常！", exception);
        }
        return FeignException.errorStatus(methodKey, response);
	}

}

