package com.powerbridge.example.dao;

import org.apache.ibatis.annotations.Param;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.powerbridge.example.entity.Echo;

/**
 * @Description: 
 * @author: shunhe@powerbridge.com
 * @Date: 2018年1月23日上午9:51:39
 */
public interface EchoMapper extends BaseMapper<Echo>{
	
	public Echo getEchoById(@Param("id") String uuid);
}

