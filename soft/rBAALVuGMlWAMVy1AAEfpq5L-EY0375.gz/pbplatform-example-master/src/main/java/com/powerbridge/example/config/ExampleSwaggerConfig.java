package com.powerbridge.example.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.google.common.collect.Sets;
import com.powerbridge.core.config.BaseSwaggerConfig;

import springfox.documentation.annotations.ApiIgnore;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
	
/**
 * @Description: swagger配置
 * @author: shunhe@powerbridge.com
 * @Date: 2018年2月24日上午11:32:52
 */
@Configuration
public class ExampleSwaggerConfig extends BaseSwaggerConfig{

	@Autowired
	private ExampleConfig config;
	
	@Bean
    public Docket customImplementation(){
		return new Docket(DocumentationType.SWAGGER_2)
				.protocols(Sets.newHashSet("http"))
				.apiInfo(apiInfo(config.getSwaggerDocTitle(), config.getSwaggerDocVersion(), config.getSwaggerDocDescription()))
				.select().paths(PathSelectors.any())
				.apis(RequestHandlerSelectors.basePackage(config.getControllerPackage()))
				.build()
				.ignoredParameterTypes(ApiIgnore.class)
				.pathMapping("/");
    }
	
}

