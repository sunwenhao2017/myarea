package com.powerbridge.example.health;

import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.boot.actuate.health.Status;
import org.springframework.stereotype.Component;

import com.powerbridge.core.itf.EurekaManageInterface;

/**
 * @Description: 
 * @author: shunhe@powerbridge.com
 * @Date: 2018年5月9日上午8:54:26
 */
@Component
public class EurekaClientHealthIndicator implements HealthIndicator{

	@Override
	public Health health() {
		if(EurekaManageInterface.upOrDown) {
			return new Health.Builder(Status.UP).withDetail("details", "").withDetail("status", Status.UP).build();
		} else {
			return new Health.Builder(Status.DOWN).withDetail("details", "").withDetail("status", Status.DOWN).build();
		}
	}
}

