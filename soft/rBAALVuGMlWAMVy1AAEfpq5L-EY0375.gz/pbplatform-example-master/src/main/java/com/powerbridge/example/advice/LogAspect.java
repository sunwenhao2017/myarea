//package com.powerbridge.example.advice;
//
//import javax.servlet.http.HttpServletRequest;
//
//import org.aspectj.lang.ProceedingJoinPoint;
//import org.aspectj.lang.annotation.AfterThrowing;
//import org.aspectj.lang.annotation.Around;
//import org.aspectj.lang.annotation.Aspect;
//import org.aspectj.lang.annotation.Pointcut;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.core.annotation.Order;
//import org.springframework.stereotype.Component;
//import org.springframework.web.context.request.RequestContextHolder;
//import org.springframework.web.context.request.ServletRequestAttributes;
//
//import com.powerbridge.core.constants.MessageConstants;
//import com.powerbridge.core.dto.AjaxResult;
//import com.powerbridge.core.util.CommonUtils;
//import com.powerbridge.core.util.ServletUtils;
//import com.powerbridge.example.service.SendService;
//
///**
// * @Description: 外部请求日志拦截
// * @author: shunhe@powerbridge.com
// * @Date: 2018年4月9日下午1:07:37
// */
//@Aspect  
//@Order(-99)
//@Component
//public class LogAspect {
//
//	@Autowired
//	private SendService sendService;
//	
//	@Pointcut("execution(* com.powerbridge.example.controller..*(..)) and @annotation(org.springframework.web.bind.annotation.RequestMapping)")
//    public void webLog(){
//		
//	}
//	
//	@Around("webLog()")
//	public Object arround(ProceedingJoinPoint pjp) throws Throwable {
//		Object o = null;
//		ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
//		//调用者ip
//        String ip = ServletUtils.getIpAddr();
//        //调用者应用id
//        String applyId = ServletUtils.getApplyId();
//        //调用者应用url
//        String url = "";
//		if(attributes!=null) {
//			HttpServletRequest request = attributes.getRequest();
//			url = request.getRequestURI();
//	        long t1 = System.currentTimeMillis();
//	        o =  pjp.proceed(); 
//	        long t2 = System.currentTimeMillis();
//	        String msg = "";
//	        if (o != null) {
//                if (o instanceof AjaxResult) {
//                    AjaxResult ajaxResult = (AjaxResult) o;
//                    msg = ajaxResult.getMessage();
//                } else {
//                    msg = "ok";
//                }
//            }
//            sendService.sendMessage(CommonUtils.getSystemLog(ip, applyId, url, 1, msg, (t2-t1)));
//		}
//		return o;
//	}
//	
//	@AfterThrowing(throwing="ex",value="webLog()")  
//    public void afterThrowing(Throwable ex){
//		ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
//		//调用者ip
//        String ip = ServletUtils.getIpAddr();
//        //调用者应用id
//        String applyId = ServletUtils.getApplyId();
//        //调用者应用url
//        String url = "";
//        if(attributes!=null) {
//			HttpServletRequest request = attributes.getRequest();
//			url = request.getRequestURI();
//        }
//		sendService.sendMessage(CommonUtils.getSystemLog(ip, applyId, url, 9999, MessageConstants.BSSP_STATUS_FAIL.getMessage(), 0));
//    }  
//	
//}
//
