package com.powerbridge.example.config;

import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

/**
 * @Description: 异步线程池
 * @author: shunhe@powerbridge.com
 * @Date: 2017年12月6日上午10:18:25
 */
@Configuration
@EnableAsync
public class AsyncExecuteConfig {

	@Autowired
	private ExampleConfig config;
	
	@Bean
	public Executor baseAsyncExecutor() {
		ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
		// 线程池维护线程的最少数量
        executor.setCorePoolSize(config.getAsyncExecPoolSize());
        // 线程池维护线程的最大数量
        executor.setMaxPoolSize(config.getAsyncExecmaxPoolSize());
        // 线程池所使用的缓冲队列
        executor.setQueueCapacity(config.getAsyncExecQueueCapacity());
        executor.setKeepAliveSeconds(config.getAsyncExecKeepAliveSec());
        executor.setThreadNamePrefix("PBPlatform-Example-AsyncExecutor-");
        executor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
        executor.initialize();
        return executor;
	}
}

