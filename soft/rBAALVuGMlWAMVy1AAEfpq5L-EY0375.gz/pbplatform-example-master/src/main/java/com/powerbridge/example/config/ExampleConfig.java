package com.powerbridge.example.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;

import com.ctrip.framework.apollo.Config;
import com.ctrip.framework.apollo.spring.annotation.ApolloConfig;
import com.powerbridge.core.aspect.RepeatSubmitAspect;

/**
 * @Description: apollo配置信息注入
 * @author: shunhe@powerbridge.com
 * @Date: 2017年11月20日上午10:14:07
 */
@Component("exampleConfig")
@ComponentScan(basePackageClasses=RepeatSubmitAspect.class)
@org.springframework.cloud.context.config.annotation.RefreshScope
public class ExampleConfig {

	@ApolloConfig
	private Config config;

	@ApolloConfig("DEPT.testpublic")
	private Config pubConfig;
	
	@Value("${spring.datasource.master.url:}")private String datasourceUrl;
	public String getMasterUrl() {
		return this.datasourceUrl;
	}
	
	@Value("${spring.datasource.master.username:}")private String datasourceUsername;
	public String getMasterUsername() {
		return this.datasourceUsername;
	}
	
	@Value("${spring.datasource.master.password:}")private String datasourcePassword;
	public String getMasterPassword() {
		return this.datasourcePassword;
	}
	
	@Value("${spring.datasource.master.driverClassName:com.mysql.jdbc.Driver}")private String datasourceDriver;
	public String getMasterDriver() {
		return this.datasourceDriver;
	}
	
	@Value("${spring.datasource.slave.url:}")private String slaveDatasourceUrl;
	public String getSlaveUrl() {
		return this.slaveDatasourceUrl;
	}
	
	@Value("${spring.datasource.slave.username:}")private String slaveDatasourceUsername;
	public String getSlaveUsername() {
		return this.slaveDatasourceUsername;
	}
	
	@Value("${spring.datasource.slave.password:}")private String slaveDatasourcePassword;
	public String getSlavePassword() {
		return this.slaveDatasourcePassword;
	}
	
	@Value("${spring.datasource.slave.driverClassName:com.mysql.jdbc.Driver}")private String slaveDatasourceDriver;
	public String getSlaveDriver() {
		return this.slaveDatasourceDriver;
	}
	
	@Value("${test.aaa:ENC(TEST)}")private String encrptorParam;
	public String getEncrpytionParams() {
		return this.encrptorParam;
	}
	
	@Value("${jasypt.encryptor.password:example}")private String encrpytorPassword;
	public String getEncryptorPassword() {
		return this.encrpytorPassword;
	}
	
	@Value("${swagger.controllerPackage:com.powerbridge}")private String swaggerControlPackage;
	public String getControllerPackage() {
		return this.swaggerControlPackage;
	}
	@Value("${swagger.title:Spring Boot + Swagger}")private String swaggerTitle;
	public String getSwaggerDocTitle() {
		return this.swaggerTitle;
	}
	@Value("${swagger.version:1.0}")private String swaggerVersion;
	public String getSwaggerDocVersion() {
		return this.swaggerVersion;
	}
	@Value("${swagger.description:Spring Boot + Swagger}")private String swaggerDesc;
	public String getSwaggerDocDescription() {
		return this.swaggerDesc;
	}
	
	@Value("${mybatis.typeAliasesPackage:com.powerbridge.example.entity}")private String mybatisAliasesPackage;
	public String getMyBatisTypeAliasesPackage() {
		return this.mybatisAliasesPackage;
	}
	
	@Value("${mybatis.mapper-locations:classpath:mapper/**/*.xml}")private String mybatisMapper;
	public String getMasterXmlLocation() {
		return this.mybatisMapper;
	}
	
	@Value("${master.paginationInterceptor:mysql}")private String mybatisPagination;
	public String getMasterPaginationInterceptor() {
		return this.mybatisPagination;
	}
	
	@Value("${eureka.apps.url:http://172.16.0.43:8870/eureka/apps}")private String eurekaClientinfoUrl;
	public String getEurekaClientinfoUrl() {
		return this.eurekaClientinfoUrl;
	}
	
	@Value("${fdfs.ipaddress:172.16.0.45}")private String fdfsHost;
	public String getFdfsHost() {
		return this.fdfsHost;
	}
	
	@Value("${taskExecutor.pool.corePoolSize:10}")private Integer asyncExeccorePoolSize;
	public int getAsyncExecPoolSize() {
		return this.asyncExeccorePoolSize;
	}
	
	@Value("${taskExecutor.pool.maxPoolSize:50}")private Integer asyncExecmaxPoolSize;
	public int getAsyncExecmaxPoolSize() {
		return this.asyncExecmaxPoolSize;
	}
	
	@Value("${taskExecutor.pool.keepAliveSeconds:100}")private Integer asyncExecKeepAliveSec;
	public int getAsyncExecKeepAliveSec() {
		return this.asyncExecKeepAliveSec;
	}
	
	@Value("${taskExecutor.pool.queueCapacity:1000}")private Integer asyncExecQueueCapacity;
	public int getAsyncExecQueueCapacity() {
		return this.asyncExecQueueCapacity;
	}

	@Value("${pb.env.lang.switch:}")private String language;
	public String getLanguage() {
		return this.language;
	}
}

