package com.powerbridge.example.config;

import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;

/**
 * @Description: 
 * @author: shunhe@powerbridge.com
 * @Date: 2018年4月17日下午5:50:21
 */
public class RWSplitRoutingDataSource extends AbstractRoutingDataSource {

	@Override
	protected Object determineCurrentLookupKey() {
		// TODO Auto-generated method stub
		return DbContextHolder.getDbType();
	}

}

