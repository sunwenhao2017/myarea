package com.powerbridge.example.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.scope.refresh.RefreshScope;
import org.springframework.stereotype.Component;

import com.ctrip.framework.apollo.model.ConfigChangeEvent;
import com.ctrip.framework.apollo.spring.annotation.ApolloConfigChangeListener;

/**
 * @Description: apollo配置实时刷新
 * @author: shunhe@powerbridge.com
 * @Date: 2017年11月20日上午10:14:07
 */
@Component
public class ExampleApolloAnnotationBean {
	
	@Autowired
	private RefreshScope refreshScope;
	
	@ApolloConfigChangeListener
	private void someOnChange(ConfigChangeEvent changeEvent) {
		refreshScope.refreshAll();
	}
	
}

