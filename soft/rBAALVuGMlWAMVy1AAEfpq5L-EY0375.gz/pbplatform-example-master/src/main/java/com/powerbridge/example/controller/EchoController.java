package com.powerbridge.example.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.powerbridge.example.service.MessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.powerbridge.core.aspect.RepeatSubmitValidation;
import com.powerbridge.core.constants.MessageConstants;
import com.powerbridge.core.controller.BaseController;
import com.powerbridge.core.dto.AjaxResult;
import com.powerbridge.core.repository.base.BaseRepository;
import com.powerbridge.core.util.RedisCacheUtils;
import com.powerbridge.core.util.UUIDGenerator;
import com.powerbridge.core.util.json.JSONObject;
import com.powerbridge.core.util.toolbox.StringUtil;
import com.powerbridge.example.client.IExampleCodClient;
import com.powerbridge.example.client.IExampleSystemClient;
import com.powerbridge.example.entity.Echo;
import com.powerbridge.example.repository.EchoRepository;
import com.powerbridge.example.service.BaseFastDFSClient;
import com.powerbridge.example.service.IEchoService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;

/**
 * @Description: 
 * @author: shunhe@powerbridge.com
 * @Date: 2018年5月29日上午10:31:10
 */
@RestController
@RequestMapping("/echo")
@Api(description="Echo Example Controller", tags= {"示例操作接口"})
@Slf4j
public class EchoController extends BaseController {

	@Autowired
	private IEchoService echoService;
	
	@Autowired
	private IExampleCodClient exampleClient;
	
	@Autowired
	private IExampleSystemClient systemClient;
	
	@Autowired
	private List<BaseRepository> repository;
	
	@Autowired
	private EchoRepository echoRepo;
	
	@Autowired
	private BaseFastDFSClient fdfsClient;
	
	@Autowired
	private RedisTemplate redis;

	@Autowired
	private MessageService messageService;
	
	@ApiOperation(value="Redis缓存测试")
	@PostMapping("/redisCache")
	@ApiResponses({
		@ApiResponse(code = 200, message = "ok", response=Echo.class)
	})
    public AjaxResult redisCache() {
		Echo e = new Echo();
		e.setId(UUIDGenerator.getUUID());
//		e.setMsg("hello redis");
		e.setMsg(messageService.getMsg("error_01"));
		RedisCacheUtils.setObject(redis, "shunhe", e, 0L);
		Echo echo = (Echo)RedisCacheUtils.getObject(redis, "shunhe");
		return new AjaxResult(MessageConstants.PB_STATUS_SUCCESS, echo);
	}
	
	@ApiOperation(value="mybatis-plus分页查询")
	@ApiResponses({
		@ApiResponse(response=Echo.class, code = 200, message = "ok", responseContainer="List")
	})
	@GetMapping("/selectPage")
    public AjaxResult selectPage() {
        EntityWrapper<Echo> entityWrapper = new EntityWrapper<>(new Echo());
        Page page = getPage();  // 分页
        String sort = getParameter("sort");
        boolean sortOrder = getOrderSort(getParameter("sortOrder"));
        if (StringUtil.isNotEmpty(sort)) {
            page.setAsc(sortOrder);
            page.setOrderByField(sort);
        } else {
            page.setAsc(true);
            page.setOrderByField("msg");  // 排序
        }
        Page<Echo> echoLists = echoService.selectPage(page, entityWrapper);
        return new AjaxResult(MessageConstants.PB_STATUS_SUCCESS, echoLists.getRecords(), page.getTotal());
    }
	
	@RepeatSubmitValidation
	@GetMapping("/selectById")
	@ApiOperation(value = "mybatis根据id查询对象")
	@ApiResponses({
		@ApiResponse(response=Echo.class, code = 200, message = "ok")
	})
	public AjaxResult selectById(@ApiParam(value="id", name="str", required=true) @RequestParam String str) {
		Echo e = echoService.selectById(str);
	    return new AjaxResult(MessageConstants.PB_STATUS_SUCCESS, e);
	}
	
	@PostMapping("/insert")
	@ApiOperation(value = "mybatis新增对象")
	@ApiResponses({
		@ApiResponse(response=Boolean.class, code = 200, message = "ok")
	})
	public AjaxResult insert(@RequestBody Echo e) {
        return new AjaxResult(MessageConstants.PB_STATUS_SUCCESS, echoService.insert(e));
    }
	
	@PostMapping("/batchInsert")
	@ApiOperation(value = "mybatis批量新增对象")
	@ApiResponses({
		@ApiResponse(response=Boolean.class, code = 200, message = "ok")
	})
	public AjaxResult batchInsert() {
		List<Echo> list = new ArrayList<>();
		for(int i=0;i<2;i++) {
			Echo e = new Echo();
			e.setMsg("batch insert "+i);
			list.add(e);
		}
        return new AjaxResult(MessageConstants.PB_STATUS_SUCCESS, echoService.batchInsertEcho(list));
    }
	
	@DeleteMapping("/deleteById")
	@ApiOperation(value = "mybatis根据id删除对象")
	@ApiResponses({
		@ApiResponse(response=Boolean.class, code = 200, message = "ok")
	})
	public AjaxResult deleteById(@ApiParam(value="id", name="id", required=true) @RequestParam String id) {
        return new AjaxResult(MessageConstants.PB_STATUS_SUCCESS, echoService.deleteById(id));
    }
	
	@PutMapping("/updateById")
	@ApiOperation(value = "mybatis根据id更新对象")
	@ApiResponses({
		@ApiResponse(response=Boolean.class, code = 200, message = "ok")
	})
	public AjaxResult updateById(@RequestBody Echo e) {
        return new AjaxResult(MessageConstants.PB_STATUS_SUCCESS, echoService.updateById(e));
    }

	@GetMapping("/findMasterAndCluster")
	@ApiOperation(value = "多数据源下查询echo对象")
	@ApiResponses({
		@ApiResponse(response=Echo.class, code = 200, message = "ok", responseContainer="List")
	})
	public List<Echo> findMasterAndCluster() {
		List<Echo> list = new ArrayList<Echo>();
	    Echo master = echoService.findByUUID("1b66d7a7-2292-48ed-81a2-1a7b8ec0e836");
	    list.add(master);
	    Echo cluster = echoService.findSlaveByUUID("1b66d7a7-2292-48ed-81a2-1a7b8ec0e868");
	    list.add(cluster);
	    return list;
	}
	
	@ApiOperation(value="服务调用分页查询")
	@PostMapping("/feign/list")
	@ApiResponses({
		@ApiResponse(response=AjaxResult.class, code = 200, message = "ok")
	})
    public AjaxResult showCodCusClassifyList(@RequestBody Map<String, Object> map) {
		return exampleClient.showCodCusClassifyList(map);
	}
	
	@ApiOperation(value="服务调用getMap")
	@PostMapping("/getMap")
	@ApiResponses({
		@ApiResponse(response=AjaxResult.class, code = 200, message = "ok")
	})
    public AjaxResult getMap(@RequestBody Map<String, Object> map) {
		return systemClient.getMap(map);
	}
	
	@ApiOperation(value="服务调用getJson")
	@PostMapping("/getJson")
	@ApiResponses({
		@ApiResponse(response=AjaxResult.class, code = 200, message = "ok")
	})
    public AjaxResult getJson(@RequestBody JSONObject json) {
		Echo echo = new Echo();
		echo.setMsg("test");
		json.put("echo", echo);
		return systemClient.getJson(json);
	}
	
//	@ApiOperation(value="jpa多数据源查询对象")
//	@PostMapping("/findJpaMultiData")
//    public List<Echo> findJpaMultiData(@RequestBody JSONObject json) {
//		List<Echo> list = new ArrayList<>();
//		Echo masterEcho = echoRepo.findByMsg(json.getString("masterMsg"));
//		DbContextHolder.setDbType(DbType.JPASLAVE);
//		Echo slaveEcho = echoRepo.findSlaveByMsg(json.getString("slaveMsg"));
//		list.add(masterEcho);
//		list.add(slaveEcho);
//		return list;
//	}
	
	@ApiOperation(value="jpa分页查询")
	@GetMapping("/selectJpaPage")
	@ApiResponses({
		@ApiResponse(response=Echo.class, code = 200, message = "ok")
	})
    public AjaxResult selectJpaPage(@ApiParam(value="type", name="type", required=true) @RequestParam String type) {
		if("echo".equals(type)) {
			type = Echo.class.getName();
		}
		for(BaseRepository repo: repository) {
			if(repo.support(type)) {
				org.springframework.data.domain.Page<Echo> page = repo.findAll(PageRequest.of(0, 10));
				return json(MessageConstants.PB_STATUS_SUCCESS, page.getContent(), page.getSize());
			}
		}
        return new AjaxResult(MessageConstants.PB_STATUS_FAIL);
    }
	
	@ApiOperation(value="jpa查询单个实体对象")
	@GetMapping("/findEchoByMsg")
	@ApiResponses({
		@ApiResponse(response=Echo.class, code = 200, message = "ok")
	})
    public AjaxResult findEchoByMsg(@ApiParam(value="msg", name="msg", required=true) @RequestParam String msg) {
		Echo echo = echoRepo.findByMsg(msg);
		return json(MessageConstants.PB_STATUS_SUCCESS, echo);
	}
	
	@ApiOperation(value="jpa更新单个实体对象")
	@PutMapping("/updateEchoById")
	@ApiResponses({
		@ApiResponse(response=AjaxResult.class, code = 200, message = "ok")
	})
    public AjaxResult updateEchoById(@RequestBody JSONObject json) {
		String id = json.getString("id");
		String msg = json.getString("msg");
		int i = echoRepo.updateById(msg, id);
		return json(MessageConstants.PB_STATUS_SUCCESS, i);
	}
	
	@ApiOperation(value="jpa保存实体")
	@PostMapping("/saveEcho")
	@ApiResponses({
		@ApiResponse(response=Echo.class, code = 200, message = "ok")
	})
    public AjaxResult saveEcho(@RequestBody JSONObject json) {
		String type = json.getString("type");
		String id = UUIDGenerator.getUUID();
		String msg = json.getString("msg");
		if("echo".equals(type)) {
			type = Echo.class.getName();
		}
		for(BaseRepository repo: repository) {
			if(repo.support(type)) {
				Echo echo = new Echo();
				echo.setMsg(msg);
				Object obj = repo.save(echo);
				return json(MessageConstants.PB_STATUS_SUCCESS, obj);
			}
		}
        return new AjaxResult(MessageConstants.PB_STATUS_FAIL);
    }
	
	@ApiOperation(value="jpa批量保存实体")
	@PostMapping("/batchSaveEcho")
	@ApiResponses({
		@ApiResponse(response=Echo.class, code = 200, message = "ok", responseContainer="List")
	})
    public AjaxResult batchSaveEcho(@RequestBody List<Echo> echiList) {
		for(Echo e:echiList) {
		}
		List<Echo> list = echoRepo.saveAll(echiList);
		return new AjaxResult(MessageConstants.PB_STATUS_SUCCESS, list);
    }
	
	@ApiOperation(value="fastDFS上传文件")
	@PostMapping("/fdfsUploadFile")
	@ApiResponses({
		@ApiResponse(response=String.class, code = 200, message = "ok")
	})
    public AjaxResult fdfsUploadFile(@ApiParam(value="file", name="file", required=true) @RequestParam MultipartFile file) {
		try {
			String imgUrl = fdfsClient.uploadFile(file);
			return new AjaxResult(200, "fdfs上传成功", imgUrl);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new AjaxResult(999, "fdfs上传失败", "");
    }
	
	@ApiOperation(value="fastDFS删除文件")
	@DeleteMapping("/fdfsDeleteFile")
    public AjaxResult fdfsDeleteFile(@ApiParam(value="filepath", name="filepath", required=true) @RequestParam String filepath) {
		fdfsClient.deleteFile(filepath);
		return new AjaxResult(200, "fdfs删除成功");
    }
}

