package com.powerbridge.example.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.powerbridge.example.annotation.Master;
import com.powerbridge.example.annotation.Slave;
import com.powerbridge.example.config.DbContextHolder;

import lombok.extern.slf4j.Slf4j;

/**
 * @Description: 
 * @author: shunhe@powerbridge.com
 * @Date: 2018年4月17日下午5:57:25
 */
@Slf4j
@Aspect
@Component
@Order(-100)
public class SwitchDatabaseAspect {
	
	@Around("@annotation(master)")
	public Object arroundMaster(ProceedingJoinPoint pjp, Master master) throws Throwable {
		try {
            log.info("set database connection to Master");
            DbContextHolder.setDbType(DbContextHolder.DbType.MASTER);
            Object result = pjp.proceed();
            return result;
        } finally {
            DbContextHolder.clearDbType();
            log.info("restore database connection");
        }
	}
	
	@Around("@annotation(slave)")
	public Object arroundSlave(ProceedingJoinPoint pjp, Slave slave) throws Throwable {
		try {
            log.info("set database connection to Slave");
            DbContextHolder.setDbType(DbContextHolder.DbType.SLAVE);
            Object result = pjp.proceed();
            return result;
        } finally {
            DbContextHolder.clearDbType();
            log.info("restore database connection");
        }
	}
}

