package com.powerbridge.example.health;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.health.Status;
import org.springframework.stereotype.Component;

import com.netflix.appinfo.HealthCheckHandler;
import com.netflix.appinfo.InstanceInfo.InstanceStatus;

/**
 * @Description: 
 * @author: shunhe@powerbridge.com
 * @Date: 2018年5月9日上午8:55:07
 */
@Component
public class EurekaHealthCheckHandler implements HealthCheckHandler {

	@Autowired
	private EurekaClientHealthIndicator halthIndicator;
	
	@Override
	public InstanceStatus getStatus(InstanceStatus currentStatus) {
		Status status = halthIndicator.health().getStatus();
		if(status.equals(Status.UP)) {
			return InstanceStatus.UP;
		} else {
			return InstanceStatus.DOWN;
		}
	}

}

