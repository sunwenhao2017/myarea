package com.powerbridge.example.config;
/**
 * @Description: 
 * @author: shunhe@powerbridge.com
 * @Date: 2018年4月17日下午5:54:06
 */
public class DbContextHolder {
	public enum DbType {
        MASTER("master"),
        SLAVE("slave");
		private String value;
		
		private DbType(String value) {
			this.value = value;
		}

		public String getValue() {
			return this.value;
		}
    }
    private static final ThreadLocal<DbType> contextHolder = new ThreadLocal<DbType>();
    
    public static void setDbType(DbType dbType) {
        if(dbType == null){
            throw new NullPointerException();
        }
        contextHolder.set(dbType);
    }
    public static DbType getDbType() {
        return contextHolder.get() == null ? DbType.MASTER : contextHolder.get();
    }
    public static void clearDbType() {
        contextHolder.remove();
    }
}

