# 关于
本实例旨在提供一个基于spring boot的微服务项目框架模板

它将使用[Gradle](https://gradle.org/)编译构建，如果还没有安装请到[如何安装Gradle](https://gradle.org/install).


**注意:**
> 永远也不要把证书信息放在源码中，你可以通过环境变量或者gradle命令行参数方式来执行相关指令
例如:  

    gradle publish -PnexusUsername=yournexususername -PnexusPassword=yournexuspasswork


## 初始化步骤

1. 修改_settings.gradle_中的 _rootProject.name_
2. 修改gradle.properties文件中的_descripiton_以及_groupId_
3. 运行下面命令下载依赖包

        gradle clean build
        
4. 使用Eclipse来导入项目以及重命名包名_com.powerbridge.example_
5. 重新导入项目并执行下面命令重新生成Eclipse/IDEA文件:

        gradle cleanIdea idea
        gradle cleanEclipse eclipse



包命名规范，在每个微服务根目录下包含了10个通用包：

 * **advice**, 定义切面.
 * **config**, 关于微服务的配置. API的配置应该定义在api子模块中.
 * **client**, 存放Feignclient接口以及Fallback类.
 * **constant**, 存放所有常量.
 * **entity**, 存放所有相关实体.
 * **dao**, mybatis数据访问层. 存放mapper类.
 * **service**, 这里定义mybatis的service层或其他服务类.
 * **repository**, 这里定义JPA接口层.
 * **controller**, 控制层.
 * **filter**, 服务启动加载，可根据需要添加逻辑.
 * **exception**, 全局统一异常
 * **util**, 存放相关工具类.


### Swagger UI
默认已经集成了Swagger 2.0 UI.你可以通过访问下面地址来访问swagger ui:
```
http://localhost:端口/swagger-ui/index.html
```

### Apollo
默认已经集成了Apollo配置中心.
参考com.powerbridge.example.config下的ApolloConfig、ExampleApolloAnnotationBean、ExampleConfig
支持公有私有配置，需要注意：
1. Apollo配置中心需要关联一个共有配置项目
2. 同时在ExampleConfig中注入关联配置的config，如@ApolloConfig("DEPT.public")
3. 启用Apollo关联配置，如@EnableApolloConfig({"application","DEPT.public"})

### 加密配置
默认example已支持加密处理.
根据需要，您可通过环境变量或者启动参数配置秘钥以便微服务解密您的配置信息，如：
```
jasypt.encryptor.password=yourpassword
```
当然，前提是已通过exmaple的JasyptEncryptionController接口加密您的配置信息


### MybatisPlus
默认已经集成了MybatisPlus.
参考com.powerbridge.example.config下的DataSourceConfig

### JPA
默认同时也集成了JPA.



